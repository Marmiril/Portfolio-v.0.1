@echo off
cd /d "%~dp0"
javaw --module-path dependency --add-modules javafx.controls,javafx.fxml,javafx.media -jar evolupong.jar