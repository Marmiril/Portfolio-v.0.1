CHEAPONG - INSTRUCCIONES DE EJECUCIÓN

1. Descarga el archivo Cheapong.zip desde el portfolio.

2. Descomprime el archivo ZIP en una carpeta de tu ordenador.

3. Entra en la carpeta Cheapong.

4. Ejecuta el archivo:

   Cheapong.vbs

5. El juego debería abrirse automáticamente.

IMPORTANTE:
- No borres ni muevas los archivos internos de la carpeta.
- El archivo Cheapong.vbs necesita que el resto de archivos permanezcan en la misma carpeta.
- Si el juego no se abre, comprueba que Java está instalado en tu equipo.

CONTENIDO DE LA CARPETA:
- Cheapong.vbs: lanzador principal del juego.
- Cheapong.bat: lanzador auxiliar.
- cheapong.jar: archivo principal de la aplicación.
- dependency/: librerías necesarias para JavaFX.

Proyecto desarrollado en Java, JavaFX y Maven.
"""

english
CHEAPONG - RUNNING INSTRUCTIONS

1. Download the Cheapong.zip file from the portfolio.

2. Extract the ZIP file into a folder on your computer.

3. Open the Cheapong folder.

4. Run the following file:

   Cheapong.vbs

5. The game should start automatically.

IMPORTANT:
- Do not delete or move the internal files inside the folder.
- The Cheapong.vbs file needs the rest of the files to remain in the same folder.
- If the game does not start, check that Java is installed on your computer.

FOLDER CONTENTS:
- Cheapong.vbs: main game launcher.
- Cheapong.bat: auxiliary launcher.
- cheapong.jar: main application file.
- dependency/: required JavaFX libraries.

Project developed with Java, JavaFX and Maven.
"""

es_path = base / "INSTRUCCIONES_CHEAPONG_ES.txt"
en_path = base / "CHEAPONG_INSTRUCTIONS_EN.txt"

es_path.write_text(spanish, encoding="utf-8")
en_path.write_text(english, encoding="utf-8")

print(f"Archivos creados:\n- {es_path}\n- {en_path}")