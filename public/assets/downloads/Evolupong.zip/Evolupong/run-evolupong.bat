@echo off
cd /d "%~dp0"
java --module-path dependency --add-modules javafx.controls,javafx.fxml,javafx.media -jar evolupong.jar
pause